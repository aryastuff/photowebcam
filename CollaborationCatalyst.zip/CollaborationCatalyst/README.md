# InnoConnect - AI-Powered Innovator Matching Platform

Connect with like-minded innovators and builders through our AI-powered matching algorithm.

## Features

- **User Authentication**: Secure login with Replit Auth
- **Smart Matching**: AI algorithm matches users based on interests, location, age, and project similarity
- **Profile Management**: Complete profiles with project descriptions and interests
- **Email Notifications**: Automatic notifications when matches are found
- **Admin Panel**: User and match management dashboard

## Live Demo

[Add your deployed URL here]

## Tech Stack

- **Backend**: Flask, SQLAlchemy, PostgreSQL
- **Frontend**: Bootstrap 5, Jinja2 templates
- **Authentication**: Replit Auth (OAuth2)
- **Deployment**: Render/Railway compatible

## Free Deployment Options

### Option 1: Render (Recommended)
1. Fork this repository to your GitHub
2. Go to [render.com](https://render.com)
3. Connect your GitHub account
4. Create new "Web Service" from your repository
5. Render will automatically detect the `render.yaml` file
6. Deploy with one click!

### Option 2: Railway
1. Fork this repository to your GitHub
2. Go to [railway.app](https://railway.app)
3. Connect your GitHub account
4. Deploy from repository
5. Railway will use the `railway.json` configuration

### Option 3: Heroku (Alternative)
1. Fork this repository
2. Create Heroku account
3. Create new app and connect to GitHub
4. Enable automatic deploys
5. Add PostgreSQL addon (free tier available)

## Environment Variables

The following environment variables are automatically set by deployment platforms:

- `DATABASE_URL` - PostgreSQL connection string
- `SESSION_SECRET` - Flask session secret
- `REPL_ID` - For Replit Auth (if using Replit)

For email notifications (optional):
- `SMTP_SERVER` - Email server (default: smtp.gmail.com)
- `SMTP_PORT` - Email port (default: 587)
- `EMAIL_USER` - SMTP username
- `EMAIL_PASSWORD` - SMTP password
- `FROM_EMAIL` - Sender email address

## Local Development

1. Clone the repository
2. Install dependencies: `pip install -e .`
3. Set up PostgreSQL database
4. Set environment variables
5. Run: `python main.py`

## Project Structure

```
├── app.py              # Flask application setup
├── main.py             # Application entry point
├── models.py           # Database models
├── routes.py           # Application routes
├── matching.py         # AI matching algorithm
├── email_service.py    # Email notification service
├── replit_auth.py      # Authentication handling
├── templates/          # HTML templates
├── static/            # CSS and static files
└── pyproject.toml     # Python dependencies
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

MIT License - feel free to use this code for your own projects!