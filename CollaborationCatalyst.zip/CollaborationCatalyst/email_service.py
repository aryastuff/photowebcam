import os
import smtplib
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import List
from models import User, Match

class EmailService:
    """Email notification service for sending match notifications"""
    
    def __init__(self):
        self.smtp_server = os.environ.get("SMTP_SERVER", "smtp.gmail.com")
        self.smtp_port = int(os.environ.get("SMTP_PORT", "587"))
        self.email_user = os.environ.get("EMAIL_USER", "")
        self.email_password = os.environ.get("EMAIL_PASSWORD", "")
        self.from_email = os.environ.get("FROM_EMAIL", self.email_user)
        
    def send_match_notification(self, user1: User, user2: User, match: Match) -> bool:
        """
        Send email notification to both matched users
        Returns True if emails were sent successfully
        """
        try:
            # Send email to user1 about user2
            success1 = self._send_individual_notification(user1, user2, match)
            # Send email to user2 about user1
            success2 = self._send_individual_notification(user2, user1, match)
            
            return success1 and success2
        except Exception as e:
            logging.error(f"Error sending match notifications: {str(e)}")
            return False
    
    def _send_individual_notification(self, recipient: User, matched_user: User, match: Match) -> bool:
        """Send individual email notification"""
        if not recipient.email or not self.email_user:
            return False
        
        try:
            subject = "🎯 New Match Found on InnoConnect!"
            
            # Create email body
            body = self._create_match_email_body(recipient, matched_user, match)
            
            # Create message
            msg = MIMEMultipart()
            msg['From'] = self.from_email
            msg['To'] = recipient.email
            msg['Subject'] = subject
            
            msg.attach(MIMEText(body, 'html'))
            
            # Send email
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.email_user, self.email_password)
                text = msg.as_string()
                server.sendmail(self.from_email, recipient.email, text)
            
            logging.info(f"Match notification sent to {recipient.email}")
            return True
            
        except Exception as e:
            logging.error(f"Error sending email to {recipient.email}: {str(e)}")
            return False
    
    def _create_match_email_body(self, recipient: User, matched_user: User, match: Match) -> str:
        """Create HTML email body for match notification"""
        
        # Determine what factors matched
        match_factors = []
        if match.interest_match:
            match_factors.append(f"🎯 Both interested in {matched_user.primary_interest}")
        if match.location_match:
            match_factors.append(f"📍 Both located in {matched_user.location}")
        if match.age_match:
            match_factors.append("🎂 Similar age range")
        if match.description_similarity > 0.5:
            match_factors.append("💡 Similar project ideas")
        
        match_factors_html = "<br>".join([f"• {factor}" for factor in match_factors])
        
        # Calculate similarity percentage
        similarity_percentage = int(match.similarity_score * 100)
        
        html_body = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
                .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }}
                .match-card {{ background: white; padding: 20px; border-radius: 8px; margin: 20px 0; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
                .score {{ font-size: 24px; font-weight: bold; color: #667eea; }}
                .factors {{ margin: 15px 0; }}
                .cta-button {{ background: #667eea; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 20px 0; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>🎉 You have a new match!</h1>
                    <p>Someone with similar interests and goals wants to connect with you</p>
                </div>
                <div class="content">
                    <div class="match-card">
                        <h2>Meet {matched_user.get_full_name()}</h2>
                        <p><strong>📧 Email:</strong> {matched_user.email}</p>
                        <p><strong>📍 Location:</strong> {matched_user.location or 'Not specified'}</p>
                        <p><strong>🎯 Primary Interest:</strong> {matched_user.primary_interest or 'Not specified'}</p>
                        <p><strong>💡 Project/Idea:</strong></p>
                        <p style="font-style: italic; background: #f0f0f0; padding: 10px; border-radius: 5px;">
                            "{matched_user.project_description or 'No description provided'}"
                        </p>
                        
                        <div style="margin-top: 20px;">
                            <p class="score">Match Score: {similarity_percentage}%</p>
                            <div class="factors">
                                <strong>Why you matched:</strong><br>
                                {match_factors_html}
                            </div>
                        </div>
                    </div>
                    
                    <p>This person shares similar interests and goals with you. Consider reaching out to explore potential collaboration opportunities!</p>
                    
                    <a href="mailto:{matched_user.email}" class="cta-button">Reach Out Now</a>
                    
                    <p style="margin-top: 30px; font-size: 12px; color: #666;">
                        You received this email because you're registered on InnoConnect and have opted in for match notifications.
                    </p>
                </div>
            </div>
        </body>
        </html>
        """
        
        return html_body
