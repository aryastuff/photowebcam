import difflib
from typing import List, Tuple
from models import User, Match
from app import db

class MatchingAlgorithm:
    """AI-powered matching algorithm for connecting innovators and builders"""
    
    def __init__(self):
        self.interest_weight = 0.3
        self.location_weight = 0.25
        self.age_weight = 0.2
        self.description_weight = 0.25
    
    def calculate_similarity(self, user1: User, user2: User) -> Tuple[float, dict]:
        """
        Calculate similarity score between two users
        Returns tuple of (similarity_score, match_details)
        """
        if user1.id == user2.id:
            return 0.0, {}
        
        # Check if users have complete profiles
        if not (user1.is_profile_complete and user2.is_profile_complete):
            return 0.0, {}
        
        match_details = {
            'interest_match': False,
            'location_match': False,
            'age_match': False,
            'description_similarity': 0.0
        }
        
        score = 0.0
        
        # 1. Primary Interest Match (30% weight)
        if user1.primary_interest and user2.primary_interest:
            if user1.primary_interest.lower() == user2.primary_interest.lower():
                score += self.interest_weight
                match_details['interest_match'] = True
        
        # 2. Location Match (25% weight)
        if user1.location and user2.location:
            if user1.location.lower().strip() == user2.location.lower().strip():
                score += self.location_weight
                match_details['location_match'] = True
        
        # 3. Age Compatibility (20% weight) - within ±3 years
        if user1.age and user2.age:
            age_diff = abs(user1.age - user2.age)
            if age_diff <= 3:
                score += self.age_weight
                match_details['age_match'] = True
        
        # 4. Project Description Similarity (25% weight)
        if user1.project_description and user2.project_description:
            desc_similarity = self._calculate_text_similarity(
                user1.project_description, 
                user2.project_description
            )
            match_details['description_similarity'] = desc_similarity
            score += desc_similarity * self.description_weight
        
        return score, match_details
    
    def _calculate_text_similarity(self, text1: str, text2: str) -> float:
        """Calculate text similarity using difflib"""
        if not text1 or not text2:
            return 0.0
        
        # Clean and normalize text
        text1_clean = text1.lower().strip()
        text2_clean = text2.lower().strip()
        
        # Use sequence matcher for similarity
        similarity = difflib.SequenceMatcher(None, text1_clean, text2_clean).ratio()
        return similarity
    
    def find_matches(self, user: User, min_score: float = 0.3) -> List[Tuple[User, float, dict]]:
        """
        Find all potential matches for a user
        Returns list of tuples: (matched_user, similarity_score, match_details)
        """
        if not user.is_profile_complete:
            return []
        
        # Get all other users with complete profiles
        potential_matches = User.query.filter(
            User.id != user.id,
            User.is_profile_complete == True
        ).all()
        
        matches = []
        for potential_match in potential_matches:
            # Check if this match already exists
            existing_match = Match.query.filter(
                ((Match.user_id == user.id) & (Match.matched_user_id == potential_match.id)) |
                ((Match.user_id == potential_match.id) & (Match.matched_user_id == user.id))
            ).first()
            
            if existing_match:
                continue
            
            similarity_score, match_details = self.calculate_similarity(user, potential_match)
            
            if similarity_score >= min_score:
                matches.append((potential_match, similarity_score, match_details))
        
        # Sort by similarity score (highest first)
        matches.sort(key=lambda x: x[1], reverse=True)
        return matches
    
    def save_matches(self, user: User, matches: List[Tuple[User, float, dict]]) -> List[Match]:
        """Save matches to database"""
        saved_matches = []
        
        for matched_user, similarity_score, match_details in matches:
            match = Match(
                user_id=user.id,
                matched_user_id=matched_user.id,
                similarity_score=similarity_score,
                interest_match=match_details.get('interest_match', False),
                location_match=match_details.get('location_match', False),
                age_match=match_details.get('age_match', False),
                description_similarity=match_details.get('description_similarity', 0.0)
            )
            
            db.session.add(match)
            saved_matches.append(match)
        
        db.session.commit()
        return saved_matches
    
    def get_match_factors_count(self, match_details: dict) -> int:
        """Count how many factors matched (for the 3+ factors requirement)"""
        count = 0
        if match_details.get('interest_match', False):
            count += 1
        if match_details.get('location_match', False):
            count += 1
        if match_details.get('age_match', False):
            count += 1
        if match_details.get('description_similarity', 0.0) > 0.5:  # High text similarity
            count += 1
        return count
