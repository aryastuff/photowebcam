from datetime import datetime
from app import db
from flask_dance.consumer.storage.sqla import OAuthConsumerMixin
from flask_login import UserMixin
from sqlalchemy import UniqueConstraint

# (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.String, primary_key=True)
    email = db.Column(db.String, unique=True, nullable=True)
    first_name = db.Column(db.String, nullable=True)
    last_name = db.Column(db.String, nullable=True)
    profile_image_url = db.Column(db.String, nullable=True)
    
    # Extended profile fields for matching platform
    age = db.Column(db.Integer, nullable=True)
    location = db.Column(db.String(100), nullable=True)
    primary_interest = db.Column(db.String(50), nullable=True)
    project_description = db.Column(db.Text, nullable=True)
    is_profile_complete = db.Column(db.Boolean, default=False)
    is_admin = db.Column(db.Boolean, default=False)

    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)

    # Relationships
    sent_matches = db.relationship('Match', foreign_keys='Match.user_id', backref='sender', lazy='dynamic')
    received_matches = db.relationship('Match', foreign_keys='Match.matched_user_id', backref='receiver', lazy='dynamic')

    def get_full_name(self):
        if self.first_name and self.last_name:
            return f"{self.first_name} {self.last_name}"
        elif self.first_name:
            return self.first_name
        elif self.last_name:
            return self.last_name
        elif self.email:
            # Use email username as fallback
            return self.email.split('@')[0].title()
        return "Unknown User"

# (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
class OAuth(OAuthConsumerMixin, db.Model):
    user_id = db.Column(db.String, db.ForeignKey(User.id))
    browser_session_key = db.Column(db.String, nullable=False)
    user = db.relationship(User)

    __table_args__ = (UniqueConstraint(
        'user_id',
        'browser_session_key',
        'provider',
        name='uq_user_browser_session_key_provider',
    ),)

class Match(db.Model):
    __tablename__ = 'matches'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String, db.ForeignKey('users.id'), nullable=False)
    matched_user_id = db.Column(db.String, db.ForeignKey('users.id'), nullable=False)
    similarity_score = db.Column(db.Float, nullable=False)
    interest_match = db.Column(db.Boolean, default=False)
    location_match = db.Column(db.Boolean, default=False)
    age_match = db.Column(db.Boolean, default=False)
    description_similarity = db.Column(db.Float, default=0.0)
    email_sent = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.now)

    # Ensure a user cannot match with themselves and no duplicate matches
    __table_args__ = (
        UniqueConstraint('user_id', 'matched_user_id', name='unique_user_match'),
    )
