# InnoConnect - AI-Powered Innovator Matching Platform

## Overview

InnoConnect is a Flask-based web application that connects innovators and builders through an AI-powered matching algorithm. The platform allows users to create profiles with their interests, location, and project descriptions, then uses intelligent matching to find compatible collaboration partners.

## System Architecture

### Backend Architecture
- **Framework**: Flask with SQLAlchemy ORM
- **Database**: PostgreSQL (configured via environment variables)
- **Authentication**: Replit Auth integration with OAuth2
- **Session Management**: Flask-Login for user sessions
- **Email Service**: SMTP-based email notifications for matches

### Frontend Architecture
- **Template Engine**: Jinja2 with Flask
- **CSS Framework**: Bootstrap 5 with dark theme
- **Icons**: Font Awesome 6.4.0
- **Styling**: Custom CSS with gradient themes and animations

### Core Components
1. **User Management**: Profile creation, authentication, and session handling
2. **Matching Algorithm**: AI-powered compatibility scoring system
3. **Email Notifications**: Automated match notification system
4. **Admin Panel**: User management and platform statistics

## Key Components

### Models (`models.py`)
- **User Model**: Extended user profiles with matching-specific fields (age, location, interests, project descriptions)
- **OAuth Model**: Replit Auth integration for secure authentication
- **Match Model**: Relationship tracking between matched users

### Matching Algorithm (`matching.py`)
- **Weighted Scoring System**: 
  - Interest compatibility (30%)
  - Location proximity (25%) 
  - Age compatibility (20%)
  - Project description similarity (25%)
- **Text Similarity**: Uses difflib for project description matching
- **Age Filtering**: ±3 year age range for compatibility

### Email Service (`email_service.py`)
- **SMTP Integration**: Configurable email server settings
- **Match Notifications**: Automated emails when users are matched
- **Template System**: HTML email templates for better user experience

### Authentication (`replit_auth.py`)
- **Replit Auth**: Seamless integration with Replit's authentication system
- **Session Storage**: Custom OAuth token storage in database
- **User Management**: Automatic user creation and login handling

## Data Flow

1. **User Registration**: New users authenticate via Replit Auth
2. **Profile Completion**: Users fill out extended profile information
3. **Match Discovery**: Algorithm calculates compatibility scores between users
4. **Match Creation**: High-scoring pairs are saved as matches
5. **Email Notifications**: Both users receive match notification emails
6. **Match Management**: Users can view and manage their matches

## External Dependencies

### Required Environment Variables
- `SESSION_SECRET`: Flask session encryption key
- `DATABASE_URL`: PostgreSQL database connection string
- `SMTP_SERVER`: Email server hostname (default: smtp.gmail.com)
- `SMTP_PORT`: Email server port (default: 587)
- `EMAIL_USER`: SMTP authentication username
- `EMAIL_PASSWORD`: SMTP authentication password
- `FROM_EMAIL`: Sender email address

### Third-Party Services
- **Replit Auth**: User authentication and profile management
- **SMTP Email Provider**: Match notification delivery
- **Bootstrap CDN**: UI framework and styling
- **Font Awesome CDN**: Icon library

## Deployment Strategy

### Environment Setup
- Flask application configured for production with ProxyFix middleware
- Database connection pooling with automatic reconnection
- Logging configured for debugging and monitoring

### Database Management
- SQLAlchemy with automatic table creation
- Database migrations handled through model updates
- Connection pooling for performance optimization

### Security Considerations
- Session management with secure cookies
- OAuth2 authentication flow
- CSRF protection through Flask-WTF integration
- Input validation and sanitization

## Changelog

- July 06, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.