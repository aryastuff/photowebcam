from flask import render_template, request, redirect, url_for, flash, session
from flask_login import current_user
from app import app, db
from replit_auth import require_login, make_replit_blueprint
from models import User, Match
from matching import MatchingAlgorithm
from email_service import EmailService

# Register the Replit Auth blueprint
app.register_blueprint(make_replit_blueprint(), url_prefix="/auth")

# Make session permanent
@app.before_request
def make_session_permanent():
    session.permanent = True

@app.route('/')
def index():
    """Landing page - shows different content based on login status"""
    if current_user.is_authenticated:
        if not current_user.is_profile_complete:
            return redirect(url_for('profile_setup'))
        return redirect(url_for('dashboard'))
    
    return render_template('index.html')

@app.route('/profile-setup', methods=['GET', 'POST'])
@require_login
def profile_setup():
    """Profile setup page for new users"""
    if request.method == 'POST':
        try:
            # Update user profile
            current_user.first_name = request.form.get('first_name', '').strip()
            current_user.last_name = request.form.get('last_name', '').strip()
            current_user.age = int(request.form.get('age', 0))
            current_user.location = request.form.get('location', '').strip()
            current_user.primary_interest = request.form.get('primary_interest', '')
            current_user.project_description = request.form.get('project_description', '').strip()[:500]  # Limit to 500 chars
            
            # Validate required fields (names are now required)
            if not all([current_user.first_name, current_user.last_name, current_user.age, current_user.location, current_user.primary_interest, current_user.project_description]):
                flash('Please fill in all required fields including your first and last name.', 'error')
                # Define interests for the template
                interests = [
                    'EdTech', 'HealthTech', 'FinTech', 'Environment', 'Mental Health',
                    'AI/ML', 'Robotics', 'E-commerce', 'Social Impact', 'Gaming',
                    'Blockchain', 'IoT', 'Clean Energy', 'Food Tech', 'Space Tech'
                ]
                return render_template('profile_setup.html', user=current_user, interests=interests)
            
            if current_user.age < 13 or current_user.age > 100:
                flash('Please enter a valid age between 13 and 100.', 'error')
                return render_template('profile_setup.html', user=current_user)
            
            if len(current_user.project_description.split()) > 100:
                flash('Project description must be 100 words or less.', 'error')
                return render_template('profile_setup.html', user=current_user)
            
            current_user.is_profile_complete = True
            db.session.commit()
            
            flash('Profile completed successfully! You can now find matches.', 'success')
            return redirect(url_for('dashboard'))
            
        except ValueError:
            flash('Please enter a valid age.', 'error')
        except Exception as e:
            flash('An error occurred while saving your profile. Please try again.', 'error')
            db.session.rollback()
    
    # Define interest options
    interests = [
        'EdTech', 'HealthTech', 'FinTech', 'Environment', 'Mental Health',
        'AI/ML', 'Robotics', 'E-commerce', 'Social Impact', 'Gaming',
        'Blockchain', 'IoT', 'Clean Energy', 'Food Tech', 'Space Tech'
    ]
    
    return render_template('profile_setup.html', user=current_user, interests=interests)

@app.route('/dashboard')
@require_login
def dashboard():
    """User dashboard showing profile and recent matches"""
    if not current_user.is_profile_complete:
        return redirect(url_for('profile_setup'))
    
    # Get recent matches for this user
    recent_matches = db.session.query(Match, User).join(
        User, Match.matched_user_id == User.id
    ).filter(
        Match.user_id == current_user.id
    ).order_by(Match.created_at.desc()).limit(5).all()
    
    return render_template('dashboard.html', user=current_user, recent_matches=recent_matches)

@app.route('/browse-users')
@require_login
def browse_users():
    """Browse all users with search functionality"""
    if not current_user.is_profile_complete:
        flash('Please complete your profile first to browse users.', 'warning')
        return redirect(url_for('profile_setup'))
    
    # Get search query
    search_query = request.args.get('search', '').strip()
    
    # Get all users except current user
    users_query = User.query.filter(
        User.id != current_user.id,
        User.is_profile_complete == True
    )
    
    # Apply search filter if provided
    if search_query:
        users_query = users_query.filter(
            db.or_(
                User.primary_interest.ilike(f'%{search_query}%'),
                User.project_description.ilike(f'%{search_query}%'),
                User.first_name.ilike(f'%{search_query}%'),
                User.last_name.ilike(f'%{search_query}%'),
                User.location.ilike(f'%{search_query}%')
            )
        )
    
    # Order by most recent
    all_users = users_query.order_by(User.created_at.desc()).all()
    
    return render_template('browse_users.html', 
                         users=all_users, 
                         search_query=search_query,
                         user=current_user)

@app.route('/user-profile/<user_id>')
@require_login
def user_profile(user_id):
    """View detailed profile of a specific user"""
    if not current_user.is_profile_complete:
        flash('Please complete your profile first.', 'warning')
        return redirect(url_for('profile_setup'))
    
    user = User.query.get_or_404(user_id)
    
    if not user.is_profile_complete:
        flash('This user has not completed their profile yet.', 'info')
        return redirect(url_for('browse_users'))
    
    # Calculate compatibility if matching algorithm is available
    compatibility_score = 0
    match_details = {}
    
    try:
        from matching import MatchingAlgorithm
        matcher = MatchingAlgorithm()
        compatibility_score, match_details = matcher.calculate_similarity(current_user, user)
    except Exception as e:
        app.logger.error(f"Could not calculate compatibility: {str(e)}")
    
    return render_template('user_profile.html', 
                         profile_user=user, 
                         compatibility_score=compatibility_score,
                         match_details=match_details,
                         user=current_user)

@app.route('/find-matches')
@require_login
def find_matches():
    """Find and display matches for the current user"""
    if not current_user.is_profile_complete:
        flash('Please complete your profile first to find matches.', 'warning')
        return redirect(url_for('profile_setup'))
    
    try:
        # Initialize matching algorithm
        matcher = MatchingAlgorithm()
        
        # Find matches
        potential_matches = matcher.find_matches(current_user, min_score=0.3)
        
        if not potential_matches:
            flash('No matches found at this time. Try updating your profile or check back later!', 'info')
            return render_template('matches.html', matches=[], user=current_user)
        
        # Save matches to database
        saved_matches = matcher.save_matches(current_user, potential_matches)
        
        # Send email notifications (optional, non-blocking)
        email_service = EmailService()
        for i, (matched_user, similarity_score, match_details) in enumerate(potential_matches):
            try:
                match = saved_matches[i]
                email_sent = email_service.send_match_notification(current_user, matched_user, match)
                match.email_sent = email_sent
                db.session.commit()
            except Exception as e:
                # Log error but don't break the flow
                app.logger.error(f"Failed to send email notification: {str(e)}")
        
        flash(f'Found {len(potential_matches)} potential matches!', 'success')
        
        # Prepare match data for template
        matches_data = []
        for i, (matched_user, similarity_score, match_details) in enumerate(potential_matches):
            match_factors_count = matcher.get_match_factors_count(match_details)
            matches_data.append({
                'user': matched_user,
                'similarity_score': similarity_score,
                'similarity_percentage': int(similarity_score * 100),
                'match_details': match_details,
                'factors_count': match_factors_count,
                'match_record': saved_matches[i]
            })
        
        return render_template('matches.html', matches=matches_data, user=current_user)
        
    except Exception as e:
        app.logger.error(f"Error finding matches: {str(e)}")
        flash('An error occurred while finding matches. Please try again.', 'error')
        return redirect(url_for('dashboard'))

@app.route('/edit-profile', methods=['GET', 'POST'])
@require_login
def edit_profile():
    """Edit user profile"""
    if request.method == 'POST':
        try:
            current_user.age = int(request.form.get('age', current_user.age))
            current_user.location = request.form.get('location', current_user.location).strip()
            current_user.primary_interest = request.form.get('primary_interest', current_user.primary_interest)
            current_user.project_description = request.form.get('project_description', current_user.project_description).strip()[:500]
            
            # Validate
            if not all([current_user.age, current_user.location, current_user.primary_interest, current_user.project_description]):
                flash('Please fill in all required fields.', 'error')
                return redirect(url_for('edit_profile'))
            
            if current_user.age < 13 or current_user.age > 100:
                flash('Please enter a valid age between 13 and 100.', 'error')
                return redirect(url_for('edit_profile'))
            
            if len(current_user.project_description.split()) > 100:
                flash('Project description must be 100 words or less.', 'error')
                return redirect(url_for('edit_profile'))
            
            db.session.commit()
            flash('Profile updated successfully!', 'success')
            return redirect(url_for('dashboard'))
            
        except ValueError:
            flash('Please enter a valid age.', 'error')
        except Exception as e:
            flash('An error occurred while updating your profile.', 'error')
            db.session.rollback()
    
    interests = [
        'EdTech', 'HealthTech', 'FinTech', 'Environment', 'Mental Health',
        'AI/ML', 'Robotics', 'E-commerce', 'Social Impact', 'Gaming',
        'Blockchain', 'IoT', 'Clean Energy', 'Food Tech', 'Space Tech'
    ]
    
    return render_template('profile_setup.html', user=current_user, interests=interests, editing=True)

@app.route('/my-matches')
@require_login
def my_matches():
    """View all matches for the current user"""
    if not current_user.is_profile_complete:
        return redirect(url_for('profile_setup'))
    
    # Get all matches for this user
    matches_query = db.session.query(Match, User).join(
        User, Match.matched_user_id == User.id
    ).filter(
        Match.user_id == current_user.id
    ).order_by(Match.similarity_score.desc()).all()
    
    matches_data = []
    for match, matched_user in matches_query:
        matches_data.append({
            'user': matched_user,
            'similarity_score': match.similarity_score,
            'similarity_percentage': int(match.similarity_score * 100),
            'match_details': {
                'interest_match': match.interest_match,
                'location_match': match.location_match,
                'age_match': match.age_match,
                'description_similarity': match.description_similarity
            },
            'match_record': match,
            'created_at': match.created_at
        })
    
    return render_template('matches.html', matches=matches_data, user=current_user, show_all=True)

@app.route('/admin')
@require_login
def admin_panel():
    """Admin panel for viewing all users and matches"""
    # Check if user is admin (you might want to implement proper admin check)
    if not current_user.is_admin and current_user.email != 'admin@example.com':
        flash('Access denied. Admin privileges required.', 'error')
        return redirect(url_for('dashboard'))
    
    # Get all users
    all_users = User.query.order_by(User.created_at.desc()).all()
    
    # Get all matches with user details
    all_matches = []
    matches_query = Match.query.order_by(Match.created_at.desc()).all()
    
    for match in matches_query:
        user1 = User.query.get(match.user_id)
        user2 = User.query.get(match.matched_user_id)
        all_matches.append((match, user1, user2))
    
    # Count statistics
    total_users = len(all_users)
    complete_profiles = len([u for u in all_users if u.is_profile_complete])
    total_matches = len(all_matches)
    
    stats = {
        'total_users': total_users,
        'complete_profiles': complete_profiles,
        'total_matches': total_matches,
        'completion_rate': int((complete_profiles / total_users * 100) if total_users > 0 else 0)
    }
    
    return render_template('admin.html', users=all_users, matches=all_matches, stats=stats)

@app.route('/make-admin/<user_id>')
@require_login
def make_admin(user_id):
    """Make a user admin (super admin only)"""
    if current_user.email != 'admin@example.com':
        flash('Access denied.', 'error')
        return redirect(url_for('dashboard'))
    
    user = User.query.get_or_404(user_id)
    user.is_admin = True
    db.session.commit()
    flash(f'{user.get_full_name()} is now an admin.', 'success')
    return redirect(url_for('admin_panel'))

@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500
